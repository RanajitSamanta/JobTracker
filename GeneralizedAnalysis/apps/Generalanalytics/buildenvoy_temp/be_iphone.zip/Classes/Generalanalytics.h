//
//  MyAppDelegate.h
//
//

#import <IBMMobileFirstPlatformFoundationHybrid/IBMMobileFirstPlatformFoundationHybrid.h>


@interface MyAppDelegate : WLAppDelegate <WLInitWebFrameworkDelegate> {
    
}

@end
